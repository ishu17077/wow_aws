var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]__12s2uxrv8n30f._.js")
R.c("server/chunks/[root-of-the-server]__0-dv9guk6-owc._.js")
R.c("server/chunks/_next-internal_server_app_favicon_ico_route_actions_0g2jjlssn1kss.js")
R.m(6218)
module.exports=R.m(6218).exports
