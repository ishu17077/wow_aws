#1:"$Sreact.fragment"
2:"/_next/static/chunks/1tq6ppe__m8m-.js"
3:I[39756,["$2"],"default"]
4:I[37457,["$2"],"default"]
7:"/_next/static/chunks/0bts8xcjgykqh.js"
8:I[5500,["$2","$7"],"Image"]
c:"ViewportBoundary"
d:I[97367,["$2"],"$c"]
f:"MetadataBoundary"
10:I[97367,["$2"],"$f"]
11:"$Sreact.suspense"
14:I[68027,["$2"],"default",1]
:HL["/_next/static/chunks/3u8s9abyu1iga.css","style"]
:HL["/_next/static/media/797e433ab948586e-s.p.0r6juujl39pe6.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/caa3a2e1cccd8315-s.p.0wgildi0cnwt9.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
5:X
b:X
6:[["children",{"s":"__PAGE__","h":514,"d":{"r":["$","$1","c",{"children":[["$","div",null,{"className":"flex flex-col flex-1 items-center justify-center bg-zinc-50 font-sans dark:bg-black","children":["$","main",null,{"className":"flex flex-1 w-full max-w-3xl flex-col items-center justify-between py-32 px-16 bg-white dark:bg-black sm:items-start","children":[["$","$L8",null,{"className":"dark:invert h-5 w-[100px]","src":"/next.svg","alt":"Next.js logo","width":100,"height":20,"priority":true}],["$","div",null,{"className":"flex flex-col items-center gap-6 text-center sm:items-start sm:text-left","children":[["$","h1",null,{"className":"max-w-xs text-3xl font-semibold leading-10 tracking-tight text-black dark:text-zinc-50","children":["To get started, edit the"," ",["$","code",null,{"className":"rounded bg-black/[.06] px-1.5 py-0.5 font-mono text-[0.9em] dark:bg-white/[.08]","children":"page.tsx"}]," ","file."]}],["$","p",null,{"className":"max-w-md text-lg leading-8 text-zinc-600 dark:text-zinc-400","children":["Looking for a starting point or more instructions? Head over to"," ",["$","a",null,{"href":"https://vercel.com/templates?framework=next.js&utm_source=create-next-app&utm_medium=appdir-template-tw&utm_campaign=create-next-app","className":"font-medium text-zinc-950 dark:text-zinc-50","children":"Templates"}]," ","or the"," ",["$","a",null,{"href":"https://nextjs.org/learn?utm_source=create-next-app&utm_medium=appdir-template-tw&utm_campaign=create-next-app","className":"font-medium text-zinc-950 dark:text-zinc-50","children":"Learning"}]," ","center."]}]]}],["$","div",null,{"className":"flex flex-col gap-4 text-base font-medium sm:flex-row","children":[["$","a",null,{"className":"flex h-12 w-full items-center justify-center gap-2 rounded-full bg-foreground px-5 text-background transition-colors hover:bg-[#383838] dark:hover:bg-[#ccc] md:w-[158px]","href":"https://vercel.com/new?utm_source=create-next-app&utm_medium=appdir-template-tw&utm_campaign=create-next-app","target":"_blank","rel":"noopener noreferrer","children":[["$","$L8",null,{"className":"dark:invert h-[14px] w-4","src":"/vercel.svg","alt":"Vercel logomark","width":16,"height":14}],"Deploy Now"]}],["$","a",null,{"className":"flex h-12 w-full items-center justify-center rounded-full border border-solid border-black/[.08] px-5 transition-colors hover:border-transparent hover:bg-black/[.04] dark:border-white/[.145] dark:hover:bg-[#1a1a1a] md:w-[158px]","href":"https://nextjs.org/docs?utm_source=create-next-app&utm_medium=appdir-template-tw&utm_campaign=create-next-app","target":"_blank","rel":"noopener noreferrer","children":"Documentation"}]]}]]}]}],["$L9"],"$La"]}],"p":true,"v":"$b"}}]]
13:X
15:X
16:X
0:{"P":null,"c":["",""],"q":"","i":false,"t":{"t":{"s":"","h":530,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/3u8s9abyu1iga.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","script","script-0",{"src":"/_next/static/chunks/1tq6ppe__m8m-.js","async":true,"nonce":"$undefined"}]],["$","html",null,{"lang":"en","className":"T19VSG_variable _8Li5zG_variable h-full antialiased","children":["$","body",null,{"className":"min-h-full flex flex-col","children":["$","$L3",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}]}]]}],"p":true,"v":"$5"},"c":"$Q6"},"h":{"r":["$","$1","h",{"children":[null,["$","$Ld",null,{"children":"$Le"}],["$","$L10",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$11",null,{"name":"Next.Metadata","children":"$L12"}]}],null]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"p":true,"v":"$13"}},"m":"$undefined","G":["$14",[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/3u8s9abyu1iga.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]]],"S":true,"r":"$15","s":"$16","a":"$@17","l":"$undefined","p":"$undefined","d":"$undefined","b":"J8nMqXZnCUqQnKby0sPnE","u":"$@18"}
19:I[97367,["$2"],"OutletBoundary"]
9:["$","script","script-0",{"src":"/_next/static/chunks/0bts8xcjgykqh.js","async":true,"nonce":"$undefined"}]
a:["$","$L19",null,{"children":["$","$11",null,{"name":"Next.MetadataOutlet","children":"$@1a"}]}]
16:300
e:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
1b:I[27201,["$2"],"IconMark"]
12:[["$","title","0",{"children":"Create Next App"}],["$","meta","1",{"name":"description","content":"Generated by create next app"}],["$","link","2",{"rel":"icon","href":"/favicon.ico?favicon.117ezoe8m31dk.ico","sizes":"48x48","type":"image/x-icon"}],["$","$L1b","3",{}]]
1a:null
16:C
13:C
15:C
b:C
5:C
18:false
17:null
