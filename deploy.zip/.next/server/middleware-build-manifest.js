globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/J8nMqXZnCUqQnKby0sPnE/_buildManifest.js",
    "static/J8nMqXZnCUqQnKby0sPnE/_ssgManifest.js",
    "static/J8nMqXZnCUqQnKby0sPnE/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/31qp8jfkw0x2h.js",
    "static/chunks/3nl7oal9_nvs2.js",
    "static/chunks/2-aubugw8unjj.js",
    "static/chunks/turbopack-3-ry682tkyiqk.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/page": {
      "otherChunks": [
        "static/chunks/31qp8jfkw0x2h.js",
        "static/chunks/3nl7oal9_nvs2.js",
        "static/chunks/2-aubugw8unjj.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/31qp8jfkw0x2h.js",
        "static/chunks/3nl7oal9_nvs2.js",
        "static/chunks/2-aubugw8unjj.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/31qp8jfkw0x2h.js",
        "static/chunks/3nl7oal9_nvs2.js",
        "static/chunks/2-aubugw8unjj.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
